These are commonly used files that have been cached locally for
efficiency and...

some of these files are not written with up to date RDF, or contain
references to files that no longer exist.  Because the RDF parser
being used is more recent than most of these files, I had to clean up
these cache files to prevent errors.  It is recommended that you do
not remove or update these cache files (unless you know what you are
doing), otherwise the validator may report addition problems caused 
by these files.

