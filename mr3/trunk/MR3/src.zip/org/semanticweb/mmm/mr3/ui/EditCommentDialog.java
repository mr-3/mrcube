/*
 * @(#)  2004/02/18
 *
 *
 * Copyright (C) 2003 The MMM Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

package org.semanticweb.mmm.mr3.ui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import org.semanticweb.mmm.mr3.data.*;
import org.semanticweb.mmm.mr3.util.*;

/**
 * @author takeshi morita
 */
public class EditCommentDialog extends JDialog implements ActionListener {

    private MR3Literal literal;

    private JTextField langField;
    private JTextArea commentArea;

    private JButton applyButton;
    private JButton cancelButton;

    private static final int DIALOG_WIDTH = 300;
    private static final int DIALOG_HEIGHT = 250;

    public EditCommentDialog(Frame rootFrame) {
        super(rootFrame, Translator.getString("EditCommentDialog.Title"), true);

        literal = new MR3Literal();

        langField = new JTextField(5);
        JComponent langFieldP = Utilities.createTitledPanel(langField, MR3Constants.LANG, 50, 20);
        commentArea = new JTextArea(5, 20);
        commentArea.setLineWrap(true);
        JScrollPane commentAreaScroll = new JScrollPane(commentArea);
        commentAreaScroll.setBorder(BorderFactory.createTitledBorder(MR3Constants.COMMENT));

        applyButton = new JButton(MR3Constants.OK);
        applyButton.setMnemonic('o');
        applyButton.addActionListener(this);
        cancelButton = new JButton(MR3Constants.CANCEL);
        cancelButton.setMnemonic('c');
        cancelButton.addActionListener(this);
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 2, 5, 5));
        buttonPanel.add(applyButton);
        buttonPanel.add(cancelButton);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(Utilities.createWestPanel(langFieldP), BorderLayout.NORTH);
        getContentPane().add(commentAreaScroll, BorderLayout.CENTER);
        getContentPane().add(Utilities.createEastPanel(buttonPanel), BorderLayout.SOUTH);

        setSize(new Dimension(DIALOG_WIDTH, DIALOG_HEIGHT));
        setLocationRelativeTo(rootFrame);
        setVisible(false);
    }

    public void setComment(String lang, String comment) {
        langField.setText(lang);
        commentArea.setText(comment);
    }

    public MR3Literal getComment() {
        return literal;
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == applyButton) {
            literal.setLanguage(langField.getText());
            literal.setString(commentArea.getText());
            commentArea.requestFocus();
            setVisible(false);
        } else if (e.getSource() == cancelButton) {
            literal.setLanguage("");
            literal.setString("");
            commentArea.requestFocus();
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        EditCommentDialog dialog = new EditCommentDialog(null);
        dialog.setVisible(true);
    }
}
