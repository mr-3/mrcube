/*
 * @(#) InsertRDFSResDialog.java
 *
 * Copyright (C) 2003-2005 The MMM Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

package org.semanticweb.mmm.mr3.ui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import org.semanticweb.mmm.mr3.data.*;
import org.semanticweb.mmm.mr3.jgraph.*;
import org.semanticweb.mmm.mr3.util.*;

/**
 * @author takeshi morita
 */
public class InsertRDFSResDialog extends JDialog {

    private JComboBox uriPrefixBox;
    private JTextField idField;
    private JLabel nsLabel;
    private JButton confirmButton;
    private JButton cancelButton;

    private ConfirmAction confirmAction;
    private CancelAction cancelAction;

    private boolean isConfirm;
    private GraphManager gmanager;

    private static final int FIELD_WIDTH = 300;
    private static final int FIELD_HEIGHT = 20;

    public InsertRDFSResDialog(GraphManager gm) {
        super(gm.getRootFrame(), true);
        gmanager = gm;
        confirmAction = new ConfirmAction();
        cancelAction = new CancelAction();

        idField = new JTextField();
        JComponent idFieldP = Utilities.createTitledPanel(idField, "ID");
        uriPrefixBox = new JComboBox();
        uriPrefixBox.addActionListener(new ChangePrefixAction());
        JComponent uriPrefixBoxP = Utilities.createTitledPanel(uriPrefixBox, MR3Constants.PREFIX);
        JPanel uriPanel = new JPanel();
        uriPanel.setLayout(new GridLayout(1, 2, 5, 5));
        uriPanel.add(uriPrefixBoxP);
        uriPanel.add(idFieldP);

        nsLabel = new JLabel("");
        JComponent nsLabelP = Utilities.createTitledPanel(nsLabel, MR3Constants.NAME_SPACE, FIELD_WIDTH, FIELD_HEIGHT);

        Component order[] = new Component[] { uriPrefixBox, idField, confirmButton, cancelButton};
        setFocusTraversalPolicy(Utilities.getMyFocusTraversalPolicy(order, 1));

        JPanel panel = new JPanel();
        setAction(panel);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(uriPanel);
        panel.add(nsLabelP);
        panel.add(getButtonPanel());
        getContentPane().add(panel);
        setResizable(false);
        setVisible(false);
    }

    private void setAction(JComponent panel) {
        ActionMap actionMap = panel.getActionMap();
        actionMap.put(confirmAction.getValue(Action.NAME), confirmAction);
        actionMap.put(cancelAction.getValue(Action.NAME), cancelAction);
        InputMap inputMap = panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        inputMap.put(KeyStroke.getKeyStroke("ENTER"), confirmAction.getValue(Action.NAME));
        inputMap.put(KeyStroke.getKeyStroke("ESCAPE"), cancelAction.getValue(Action.NAME));
    }

    private JComponent getButtonPanel() {
        confirmButton = new JButton(confirmAction);
        confirmButton.setMnemonic('o');
        cancelButton = new JButton(cancelAction);
        cancelButton.setMnemonic('c');
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 2, 5, 5));
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        return Utilities.createEastPanel(buttonPanel);
    }

    public void initData(String title) {
        setTitle(title);
        idField.setText("");
        PrefixNSUtil.setPrefixNSInfoSet(GraphUtilities.getPrefixNSInfoSet());
        uriPrefixBox.setModel(new DefaultComboBoxModel(PrefixNSUtil.getPrefixes().toArray()));
        uriPrefixBox.setSelectedItem(PrefixNSUtil.getBaseURIPrefix(gmanager.getBaseURI()));
        PrefixNSUtil.replacePrefix((String) uriPrefixBox.getSelectedItem(), nsLabel);
        pack();
        setLocationRelativeTo(gmanager.getRootFrame());
        setVisible(true);
    }

    class ChangePrefixAction extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            PrefixNSUtil.replacePrefix((String) uriPrefixBox.getSelectedItem(), nsLabel);
        }
    }

    public boolean isConfirm() {
        return isConfirm;
    }

    public String getURI() {
        return nsLabel.getText() + idField.getText();
    }

    class ConfirmAction extends AbstractAction {
        ConfirmAction() {
            super(MR3Constants.OK);
        }

        public void actionPerformed(ActionEvent e) {
            isConfirm = true;
            idField.requestFocus(); // �_�C�A���O���\������Ă��鎞�ɁCrequestFocus���Ȃ��Ƃ����Ȃ�
            setVisible(false);
        }
    }

    class CancelAction extends AbstractAction {
        CancelAction() {
            super(MR3Constants.CANCEL);
        }

        public void actionPerformed(ActionEvent e) {
            isConfirm = false;
            idField.requestFocus(); // �_�C�A���O���\������Ă��鎞�ɁCrequestFocus���Ȃ��Ƃ����Ȃ�
            setVisible(false);
        }
    }
}
